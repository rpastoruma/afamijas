<?php
/*
 * Created by Artureanec
*/

# Excerpt Truncate
if (!function_exists('ukraine_excerpt_truncate')) {
    function helpo_excerpt_truncate($helpo_string, $helpo_length = 80, $helpo_etc = '... ', $helpo_break_words = false, $helpo_middle = false)
    {
        if ($helpo_length == 0)
            return '';

        if (mb_strlen($helpo_string, 'utf8') > $helpo_length) {
            $helpo_length -= mb_strlen($helpo_etc, 'utf8');
            if (!$helpo_break_words && !$helpo_middle) {
                $helpo_string = preg_replace('/\s+\S+\s*$/su', '', mb_substr($helpo_string, 0, $helpo_length + 1, 'utf8'));
            }
            if (!$helpo_middle) {
                return mb_substr($helpo_string, 0, $helpo_length, 'utf8') . $helpo_etc;
            } else {
                return mb_substr($helpo_string, 0, $helpo_length / 2, 'utf8') . $helpo_etc . mb_substr($helpo_string, -$helpo_length / 2, utf8);
            }
        } else {
            return $helpo_string;
        }
    }
}
